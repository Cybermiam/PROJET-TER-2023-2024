<template >
    <p>je suis le composant Graphe</p>
</template>