<template >
    <p>je suis le composant Sparnatural</p>
</template>